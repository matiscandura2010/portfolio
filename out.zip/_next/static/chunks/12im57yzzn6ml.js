(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,59941,e=>{"use strict";var t=e.i(43476),r=e.i(71645);e.s(["default",0,function({SIM_RESOLUTION:e=128,DYE_RESOLUTION:i=1440,CAPTURE_RESOLUTION:o=512,DENSITY_DISSIPATION:n=3.5,VELOCITY_DISSIPATION:a=2,PRESSURE:u=.1,PRESSURE_ITERATIONS:l=20,CURL:c=3,SPLAT_RADIUS:v=.2,SPLAT_FORCE:f=6e3,SHADING:s=!0,COLOR_UPDATE_SPEED:m=10,BACK_COLOR:h={r:.5,g:0,b:0},TRANSPARENT:d=!0,RAINBOW_MODE:g=!0,COLOR:x="#ff0000"}){let T=(0,r.useRef)(null),E=(0,r.useRef)(null);return(0,r.useEffect)(()=>{let t,r,o,h,d,R,p=T.current;if(!p)return;let D=!0,S={SIM_RESOLUTION:e,DYE_RESOLUTION:i,DENSITY_DISSIPATION:n,VELOCITY_DISSIPATION:a,PRESSURE:u,PRESSURE_ITERATIONS:l,CURL:c,SPLAT_RADIUS:v,SPLAT_FORCE:f,SHADING:s,COLOR_UPDATE_SPEED:m,RAINBOW_MODE:g,COLOR:x},A=[new function(){this.id=-1,this.texcoordX=0,this.texcoordY=0,this.prevTexcoordX=0,this.prevTexcoordY=0,this.deltaX=0,this.deltaY=0,this.down=!1,this.moved=!1,this.color=[0,0,0]}],{gl:_,ext:y}=function(e){let t,r,i,o,n,a={alpha:!0,depth:!1,stencil:!1,antialias:!1,preserveDrawingBuffer:!1},u=e.getContext("webgl2",a),l=!!u;if(l||(u=e.getContext("webgl",a)||e.getContext("experimental-webgl",a)),!u)return{gl:null,ext:{}};l?(u.getExtension("EXT_color_buffer_float"),r=u.getExtension("OES_texture_float_linear")):(t=u.getExtension("OES_texture_half_float"),r=u.getExtension("OES_texture_half_float_linear")),u.clearColor(0,0,0,1);let c=l?u.HALF_FLOAT:t&&t.HALF_FLOAT_OES;return l?(i=w(u,u.RGBA16F,u.RGBA,c),o=w(u,u.RG16F,u.RG,c),n=w(u,u.R16F,u.RED,c)):(i=w(u,u.RGBA,u.RGBA,c),o=w(u,u.RGBA,u.RGBA,c),n=w(u,u.RGBA,u.RGBA,c)),{gl:u,ext:{formatRGBA:i,formatRG:o,formatR:n,halfFloatTexType:c,supportLinearFiltering:r}}}(p);if(y&&y.supportLinearFiltering||(S.DYE_RESOLUTION=256,S.SHADING=!1),!_)return;function w(e,t,r,i){var o,n,a,u;let l,c;if(o=e,n=t,a=r,u=i,l=o.createTexture(),o.bindTexture(o.TEXTURE_2D,l),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_MAG_FILTER,o.NEAREST),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_WRAP_S,o.CLAMP_TO_EDGE),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_WRAP_T,o.CLAMP_TO_EDGE),o.texImage2D(o.TEXTURE_2D,0,n,4,4,0,a,u,null),c=o.createFramebuffer(),o.bindFramebuffer(o.FRAMEBUFFER,c),o.framebufferTexture2D(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,l,0),o.checkFramebufferStatus(o.FRAMEBUFFER)!==o.FRAMEBUFFER_COMPLETE)switch(t){case e.R16F:return w(e,e.RG16F,e.RG,i);case e.RG16F:return w(e,e.RGBA16F,e.RGBA,i);default:return null}return{internalFormat:t,format:r}}class F{constructor(e,t){this.uniforms={},this.program=U(e,t),this.uniforms=L(this.program)}bind(){_.useProgram(this.program)}}function U(e,t){let r=_.createProgram();return _.attachShader(r,e),_.attachShader(r,t),_.linkProgram(r),_.getProgramParameter(r,_.LINK_STATUS)||console.trace(_.getProgramInfoLog(r)),r}function L(e){let t=[],r=_.getProgramParameter(e,_.ACTIVE_UNIFORMS);for(let i=0;i<r;i++){let r=_.getActiveUniform(e,i).name;t[r]=_.getUniformLocation(e,r)}return t}function b(e,t,r){t=function(e,t){if(!t)return e;let r="";return t.forEach(e=>{r+="#define "+e+"\n"}),r+e}(t,r);let i=_.createShader(e);return _.shaderSource(i,t),_.compileShader(i),_.getShaderParameter(i,_.COMPILE_STATUS)||console.trace(_.getShaderInfoLog(i)),i}let B=b(_.VERTEX_SHADER,`
        precision highp float;
        attribute vec2 aPosition;
        varying vec2 vUv;
        varying vec2 vL;
        varying vec2 vR;
        varying vec2 vT;
        varying vec2 vB;
        uniform vec2 texelSize;

        void main () {
            vUv = aPosition * 0.5 + 0.5;
            vL = vUv - vec2(texelSize.x, 0.0);
            vR = vUv + vec2(texelSize.x, 0.0);
            vT = vUv + vec2(0.0, texelSize.y);
            vB = vUv - vec2(0.0, texelSize.y);
            gl_Position = vec4(aPosition, 0.0, 1.0);
        }
      `),P=b(_.FRAGMENT_SHADER,`
        precision mediump float;
        precision mediump sampler2D;
        varying highp vec2 vUv;
        uniform sampler2D uTexture;

        void main () {
            gl_FragColor = texture2D(uTexture, vUv);
        }
      `),X=b(_.FRAGMENT_SHADER,`
        precision mediump float;
        precision mediump sampler2D;
        varying highp vec2 vUv;
        uniform sampler2D uTexture;
        uniform float value;

        void main () {
            gl_FragColor = value * texture2D(uTexture, vUv);
        }
      `),C=`
      precision highp float;
      precision highp sampler2D;
      varying vec2 vUv;
      varying vec2 vL;
      varying vec2 vR;
      varying vec2 vT;
      varying vec2 vB;
      uniform sampler2D uTexture;
      uniform sampler2D uDithering;
      uniform vec2 ditherScale;
      uniform vec2 texelSize;

      vec3 linearToGamma (vec3 color) {
          color = max(color, vec3(0));
          return max(1.055 * pow(color, vec3(0.416666667)) - 0.055, vec3(0));
      }

      void main () {
          vec3 c = texture2D(uTexture, vUv).rgb;
          #ifdef SHADING
              vec3 lc = texture2D(uTexture, vL).rgb;
              vec3 rc = texture2D(uTexture, vR).rgb;
              vec3 tc = texture2D(uTexture, vT).rgb;
              vec3 bc = texture2D(uTexture, vB).rgb;

              float dx = length(rc) - length(lc);
              float dy = length(tc) - length(bc);

              vec3 n = normalize(vec3(dx, dy, length(texelSize)));
              vec3 l = vec3(0.0, 0.0, 1.0);

              float diffuse = clamp(dot(n, l) + 0.7, 0.7, 1.0);
              c *= diffuse;
          #endif

          float a = max(c.r, max(c.g, c.b));
          gl_FragColor = vec4(c, a);
      }
    `,z=b(_.FRAGMENT_SHADER,`
        precision highp float;
        precision highp sampler2D;
        varying vec2 vUv;
        uniform sampler2D uTarget;
        uniform float aspectRatio;
        uniform vec3 color;
        uniform vec2 point;
        uniform float radius;

        void main () {
            vec2 p = vUv - point.xy;
            p.x *= aspectRatio;
            vec3 splat = exp(-dot(p, p) / radius) * color;
            vec3 base = texture2D(uTarget, vUv).xyz;
            gl_FragColor = vec4(base + splat, 1.0);
        }
      `),I=b(_.FRAGMENT_SHADER,`
        precision highp float;
        precision highp sampler2D;
        varying vec2 vUv;
        uniform sampler2D uVelocity;
        uniform sampler2D uSource;
        uniform vec2 texelSize;
        uniform vec2 dyeTexelSize;
        uniform float dt;
        uniform float dissipation;

        vec4 bilerp (sampler2D sam, vec2 uv, vec2 tsize) {
            vec2 st = uv / tsize - 0.5;
            vec2 iuv = floor(st);
            vec2 fuv = fract(st);

            vec4 a = texture2D(sam, (iuv + vec2(0.5, 0.5)) * tsize);
            vec4 b = texture2D(sam, (iuv + vec2(1.5, 0.5)) * tsize);
            vec4 c = texture2D(sam, (iuv + vec2(0.5, 1.5)) * tsize);
            vec4 d = texture2D(sam, (iuv + vec2(1.5, 1.5)) * tsize);

            return mix(mix(a, b, fuv.x), mix(c, d, fuv.x), fuv.y);
        }

        void main () {
            #ifdef MANUAL_FILTERING
                vec2 coord = vUv - dt * bilerp(uVelocity, vUv, texelSize).xy * texelSize;
                vec4 result = bilerp(uSource, coord, dyeTexelSize);
            #else
                vec2 coord = vUv - dt * texture2D(uVelocity, vUv).xy * texelSize;
                vec4 result = texture2D(uSource, coord);
            #endif
            float decay = 1.0 + dissipation * dt;
            gl_FragColor = result / decay;
        }
      `,y.supportLinearFiltering?null:["MANUAL_FILTERING"]),N=b(_.FRAGMENT_SHADER,`
        precision mediump float;
        precision mediump sampler2D;
        varying highp vec2 vUv;
        varying highp vec2 vL;
        varying highp vec2 vR;
        varying highp vec2 vT;
        varying highp vec2 vB;
        uniform sampler2D uVelocity;

        void main () {
            float L = texture2D(uVelocity, vL).x;
            float R = texture2D(uVelocity, vR).x;
            float T = texture2D(uVelocity, vT).y;
            float B = texture2D(uVelocity, vB).y;

            vec2 C = texture2D(uVelocity, vUv).xy;
            if (vL.x < 0.0) { L = -C.x; }
            if (vR.x > 1.0) { R = -C.x; }
            if (vT.y > 1.0) { T = -C.y; }
            if (vB.y < 0.0) { B = -C.y; }

            float div = 0.5 * (R - L + T - B);
            gl_FragColor = vec4(div, 0.0, 0.0, 1.0);
        }
      `),M=b(_.FRAGMENT_SHADER,`
        precision mediump float;
        precision mediump sampler2D;
        varying highp vec2 vUv;
        varying highp vec2 vL;
        varying highp vec2 vR;
        varying highp vec2 vT;
        varying highp vec2 vB;
        uniform sampler2D uVelocity;

        void main () {
            float L = texture2D(uVelocity, vL).y;
            float R = texture2D(uVelocity, vR).y;
            float T = texture2D(uVelocity, vT).x;
            float B = texture2D(uVelocity, vB).x;
            float vorticity = R - L - T + B;
            gl_FragColor = vec4(0.5 * vorticity, 0.0, 0.0, 1.0);
        }
      `),O=b(_.FRAGMENT_SHADER,`
        precision highp float;
        precision highp sampler2D;
        varying vec2 vUv;
        varying vec2 vL;
        varying vec2 vR;
        varying vec2 vT;
        varying vec2 vB;
        uniform sampler2D uVelocity;
        uniform sampler2D uCurl;
        uniform float curl;
        uniform float dt;

        void main () {
            float L = texture2D(uCurl, vL).x;
            float R = texture2D(uCurl, vR).x;
            float T = texture2D(uCurl, vT).x;
            float B = texture2D(uCurl, vB).x;
            float C = texture2D(uCurl, vUv).x;

            vec2 force = 0.5 * vec2(abs(T) - abs(B), abs(R) - abs(L));
            force /= length(force) + 0.0001;
            force *= curl * C;
            force.y *= -1.0;

            vec2 velocity = texture2D(uVelocity, vUv).xy;
            velocity += force * dt;
            velocity = min(max(velocity, -1000.0), 1000.0);
            gl_FragColor = vec4(velocity, 0.0, 1.0);
        }
      `),G=b(_.FRAGMENT_SHADER,`
        precision mediump float;
        precision mediump sampler2D;
        varying highp vec2 vUv;
        varying highp vec2 vL;
        varying highp vec2 vR;
        varying highp vec2 vT;
        varying highp vec2 vB;
        uniform sampler2D uPressure;
        uniform sampler2D uDivergence;

        void main () {
            float L = texture2D(uPressure, vL).x;
            float R = texture2D(uPressure, vR).x;
            float T = texture2D(uPressure, vT).x;
            float B = texture2D(uPressure, vB).x;
            float C = texture2D(uPressure, vUv).x;
            float divergence = texture2D(uDivergence, vUv).x;
            float pressure = (L + R + B + T - divergence) * 0.25;
            gl_FragColor = vec4(pressure, 0.0, 0.0, 1.0);
        }
      `),Y=b(_.FRAGMENT_SHADER,`
        precision mediump float;
        precision mediump sampler2D;
        varying highp vec2 vUv;
        varying highp vec2 vL;
        varying highp vec2 vR;
        varying highp vec2 vT;
        varying highp vec2 vB;
        uniform sampler2D uPressure;
        uniform sampler2D uVelocity;

        void main () {
            float L = texture2D(uPressure, vL).x;
            float R = texture2D(uPressure, vR).x;
            float T = texture2D(uPressure, vT).x;
            float B = texture2D(uPressure, vB).x;
            vec2 velocity = texture2D(uVelocity, vUv).xy;
            velocity.xy -= vec2(R - L, T - B);
            gl_FragColor = vec4(velocity, 0.0, 1.0);
        }
      `),V=(_.bindBuffer(_.ARRAY_BUFFER,_.createBuffer()),_.bufferData(_.ARRAY_BUFFER,new Float32Array([-1,-1,-1,1,1,1,1,-1]),_.STATIC_DRAW),_.bindBuffer(_.ELEMENT_ARRAY_BUFFER,_.createBuffer()),_.bufferData(_.ELEMENT_ARRAY_BUFFER,new Uint16Array([0,1,2,0,2,3]),_.STATIC_DRAW),_.vertexAttribPointer(0,2,_.FLOAT,!1,0,0),_.enableVertexAttribArray(0),(e,t=!1)=>{null==e?(_.viewport(0,0,_.drawingBufferWidth,_.drawingBufferHeight),_.bindFramebuffer(_.FRAMEBUFFER,null)):(_.viewport(0,0,e.width,e.height),_.bindFramebuffer(_.FRAMEBUFFER,e.fbo)),t&&(_.clearColor(0,0,0,1),_.clear(_.COLOR_BUFFER_BIT)),_.drawElements(_.TRIANGLES,6,_.UNSIGNED_SHORT,0)}),H=new F(B,P),W=new F(B,X),k=new F(B,z),K=new F(B,I),j=new F(B,N),q=new F(B,M),J=new F(B,O),Q=new F(B,G),Z=new F(B,Y),$=new class{constructor(e,t){this.vertexShader=e,this.fragmentShaderSource=t,this.programs=[],this.activeProgram=null,this.uniforms=[]}setKeywords(e){let t=0;for(let r=0;r<e.length;r++)t+=function(e){if(0===e.length)return 0;let t=0;for(let r=0;r<e.length;r++)t=(t<<5)-t+e.charCodeAt(r)|0;return t}(e[r]);let r=this.programs[t];if(null==r){let i=b(_.FRAGMENT_SHADER,this.fragmentShaderSource,e);r=U(this.vertexShader,i),this.programs[t]=r}r!==this.activeProgram&&(this.uniforms=L(r),this.activeProgram=r)}bind(){_.useProgram(this.activeProgram)}}(B,C);function ee(){let e=ev(S.SIM_RESOLUTION),i=ev(S.DYE_RESOLUTION),n=y.halfFloatTexType,a=y.formatRGBA,u=y.formatRG,l=y.formatR,c=y.supportLinearFiltering?_.LINEAR:_.NEAREST;_.disable(_.BLEND),t=t?ei(t,i.width,i.height,a.internalFormat,a.format,n,c):er(i.width,i.height,a.internalFormat,a.format,n,c),r=r?ei(r,e.width,e.height,u.internalFormat,u.format,n,c):er(e.width,e.height,u.internalFormat,u.format,n,c),o=et(e.width,e.height,l.internalFormat,l.format,n,_.NEAREST),h=et(e.width,e.height,l.internalFormat,l.format,n,_.NEAREST),d=er(e.width,e.height,l.internalFormat,l.format,n,_.NEAREST)}function et(e,t,r,i,o,n){_.activeTexture(_.TEXTURE0);let a=_.createTexture();_.bindTexture(_.TEXTURE_2D,a),_.texParameteri(_.TEXTURE_2D,_.TEXTURE_MIN_FILTER,n),_.texParameteri(_.TEXTURE_2D,_.TEXTURE_MAG_FILTER,n),_.texParameteri(_.TEXTURE_2D,_.TEXTURE_WRAP_S,_.CLAMP_TO_EDGE),_.texParameteri(_.TEXTURE_2D,_.TEXTURE_WRAP_T,_.CLAMP_TO_EDGE),_.texImage2D(_.TEXTURE_2D,0,r,e,t,0,i,o,null);let u=_.createFramebuffer();_.bindFramebuffer(_.FRAMEBUFFER,u),_.framebufferTexture2D(_.FRAMEBUFFER,_.COLOR_ATTACHMENT0,_.TEXTURE_2D,a,0),_.viewport(0,0,e,t),_.clear(_.COLOR_BUFFER_BIT);let l=1/e,c=1/t;return{texture:a,fbo:u,width:e,height:t,texelSizeX:l,texelSizeY:c,attach:e=>(_.activeTexture(_.TEXTURE0+e),_.bindTexture(_.TEXTURE_2D,a),e)}}function er(e,t,r,i,o,n){let a=et(e,t,r,i,o,n),u=et(e,t,r,i,o,n);return{width:e,height:t,texelSizeX:a.texelSizeX,texelSizeY:a.texelSizeY,get read(){return a},set read(value){a=value},get write(){return u},set write(value){u=value},swap(){let e=a;a=u,u=e}}}function ei(e,t,r,i,o,n,a){var u;let l;return e.width===t&&e.height===r?e:(u=e.read,l=et(t,r,i,o,n,a),H.bind(),_.uniform1i(H.uniforms.uTexture,u.attach(0)),V(l),e.read=l,e.write=et(t,r,i,o,n,a),e.width=t,e.height=r,e.texelSizeX=1/t,e.texelSizeY=1/r,e)}R=[],S.SHADING&&R.push("SHADING"),$.setKeywords(R),ee();let eo=Date.now(),en=0;function ea(e,i,o,n,a){var u;let l;k.bind(),_.uniform1i(k.uniforms.uTarget,r.read.attach(0)),_.uniform1f(k.uniforms.aspectRatio,p.width/p.height),_.uniform2f(k.uniforms.point,e,i),_.uniform3f(k.uniforms.color,o,n,0),_.uniform1f(k.uniforms.radius,(u=S.SPLAT_RADIUS/100,(l=p.width/p.height)>1&&(u*=l),u)),V(r.write),r.swap(),_.uniform1i(k.uniforms.uTarget,t.read.attach(0)),_.uniform3f(k.uniforms.color,a.r,a.g,a.b),V(t.write),t.swap()}function eu(e,t,r,i){e.id=t,e.down=!0,e.moved=!1,e.texcoordX=r/p.width,e.texcoordY=1-i/p.height,e.prevTexcoordX=e.texcoordX,e.prevTexcoordY=e.texcoordY,e.deltaX=0,e.deltaY=0,e.color=ec()}function el(e,t,r,i){var o,n;let a,u;e.prevTexcoordX=e.texcoordX,e.prevTexcoordY=e.texcoordY,e.texcoordX=t/p.width,e.texcoordY=1-r/p.height,o=e.texcoordX-e.prevTexcoordX,(a=p.width/p.height)<1&&(o*=a),e.deltaX=o,n=e.texcoordY-e.prevTexcoordY,(u=p.width/p.height)>1&&(n/=u),e.deltaY=n,e.moved=Math.abs(e.deltaX)>0||Math.abs(e.deltaY)>0,e.color=i}function ec(){if(!S.RAINBOW_MODE){let e,t;return 3===(e=S.COLOR.replace("#","")).length&&(e=e[0]+e[0]+e[1]+e[1]+e[2]+e[2]),t=parseInt(e.slice(0,2),16)/255,{r:.15*t,g:.15*(parseInt(e.slice(2,4),16)/255),b:.15*(parseInt(e.slice(4,6),16)/255)}}let e=function(e){let t,r,i,o,n,a,u,l;switch(o=Math.floor(6*e),n=6*e-o,a=0,u=+(1-n),l=+(1-(1-n)*1),o%6){case 0:t=1,r=l,i=a;break;case 1:t=u,r=1,i=a;break;case 2:t=a,r=1,i=l;break;case 3:t=a,r=u,i=1;break;case 4:t=l,r=a,i=1;break;case 5:t=1,r=a,i=u}return{r:t,g:r,b:i}}(Math.random());return e.r*=.15,e.g*=.15,e.b*=.15,e}function ev(e){let t=_.drawingBufferWidth/_.drawingBufferHeight;t<1&&(t=1/t);let r=Math.round(e),i=Math.round(e*t);return _.drawingBufferWidth>_.drawingBufferHeight?{width:i,height:r}:{width:r,height:i}}function ef(e){return Math.floor(e*(window.devicePixelRatio||1))}function es(e){let t,r,i,o=A[0];eu(o,-1,ef(e.clientX),ef(e.clientY)),t=ec(),t.r*=10,t.g*=10,t.b*=10,r=10*(Math.random()-.5),i=30*(Math.random()-.5),ea(o.texcoordX,o.texcoordY,r,i,t)}let em=!1;function eh(e){let t=A[0],r=ef(e.clientX),i=ef(e.clientY);em?el(t,r,i,t.color):(el(t,r,i,ec()),em=!0)}function ed(e){let t=e.targetTouches,r=A[0];for(let e=0;e<t.length;e++){let i=ef(t[e].clientX),o=ef(t[e].clientY);eu(r,t[e].identifier,i,o)}}function eg(e){let t=e.targetTouches,r=A[0];for(let e=0;e<t.length;e++)el(r,ef(t[e].clientX),ef(t[e].clientY),r.color)}function ex(e){let t=e.changedTouches,r=A[0];for(let e=0;e<t.length;e++)r.down=!1}return window.addEventListener("mousedown",es),window.addEventListener("mousemove",eh),window.addEventListener("touchstart",ed),window.addEventListener("touchmove",eg,!1),window.addEventListener("touchend",ex),!function e(){var i,n;let a,u,l,c,v,f,s;if(!D)return;let m=(u=Math.min(u=((a=Date.now())-eo)/1e3,.016666),eo=a,u);l=ef(p.clientWidth),c=ef(p.clientHeight),(p.width!==l||p.height!==c)&&(p.width=l,p.height=c,1)&&ee(),(en+=m*S.COLOR_UPDATE_SPEED)>=1&&(i=en,en=0==(v=1)?0:(i-0)%v+0,A.forEach(e=>{e.color=ec()})),A.forEach(e=>{var t;let r,i;e.moved&&(e.moved=!1,r=(t=e).deltaX*S.SPLAT_FORCE,i=t.deltaY*S.SPLAT_FORCE,ea(t.texcoordX,t.texcoordY,r,i,t.color))}),function(e){_.disable(_.BLEND),q.bind(),_.uniform2f(q.uniforms.texelSize,r.texelSizeX,r.texelSizeY),_.uniform1i(q.uniforms.uVelocity,r.read.attach(0)),V(h),J.bind(),_.uniform2f(J.uniforms.texelSize,r.texelSizeX,r.texelSizeY),_.uniform1i(J.uniforms.uVelocity,r.read.attach(0)),_.uniform1i(J.uniforms.uCurl,h.attach(1)),_.uniform1f(J.uniforms.curl,S.CURL),_.uniform1f(J.uniforms.dt,e),V(r.write),r.swap(),j.bind(),_.uniform2f(j.uniforms.texelSize,r.texelSizeX,r.texelSizeY),_.uniform1i(j.uniforms.uVelocity,r.read.attach(0)),V(o),W.bind(),_.uniform1i(W.uniforms.uTexture,d.read.attach(0)),_.uniform1f(W.uniforms.value,S.PRESSURE),V(d.write),d.swap(),Q.bind(),_.uniform2f(Q.uniforms.texelSize,r.texelSizeX,r.texelSizeY),_.uniform1i(Q.uniforms.uDivergence,o.attach(0));for(let e=0;e<S.PRESSURE_ITERATIONS;e++)_.uniform1i(Q.uniforms.uPressure,d.read.attach(1)),V(d.write),d.swap();Z.bind(),_.uniform2f(Z.uniforms.texelSize,r.texelSizeX,r.texelSizeY),_.uniform1i(Z.uniforms.uPressure,d.read.attach(0)),_.uniform1i(Z.uniforms.uVelocity,r.read.attach(1)),V(r.write),r.swap(),K.bind(),_.uniform2f(K.uniforms.texelSize,r.texelSizeX,r.texelSizeY),y.supportLinearFiltering||_.uniform2f(K.uniforms.dyeTexelSize,r.texelSizeX,r.texelSizeY);let i=r.read.attach(0);_.uniform1i(K.uniforms.uVelocity,i),_.uniform1i(K.uniforms.uSource,i),_.uniform1f(K.uniforms.dt,e),_.uniform1f(K.uniforms.dissipation,S.VELOCITY_DISSIPATION),V(r.write),r.swap(),y.supportLinearFiltering||_.uniform2f(K.uniforms.dyeTexelSize,t.texelSizeX,t.texelSizeY),_.uniform1i(K.uniforms.uVelocity,r.read.attach(0)),_.uniform1i(K.uniforms.uSource,t.read.attach(1)),_.uniform1f(K.uniforms.dissipation,S.DENSITY_DISSIPATION),V(t.write),t.swap()}(m),_.blendFunc(_.ONE,_.ONE_MINUS_SRC_ALPHA),_.enable(_.BLEND),f=(n=null,_.drawingBufferWidth),s=null==n?_.drawingBufferHeight:n.height,$.bind(),S.SHADING&&_.uniform2f($.uniforms.texelSize,1/f,1/s),_.uniform1i($.uniforms.uTexture,t.read.attach(0)),V(n),E.current=requestAnimationFrame(e)}(),()=>{D=!1,E.current&&(cancelAnimationFrame(E.current),E.current=null),window.removeEventListener("mousedown",es),window.removeEventListener("mousemove",eh),window.removeEventListener("touchstart",ed),window.removeEventListener("touchmove",eg),window.removeEventListener("touchend",ex)}},[]),(0,t.jsx)("div",{style:{position:"fixed",top:0,left:0,zIndex:0,pointerEvents:"none",width:"100%",height:"100%"},children:(0,t.jsx)("canvas",{ref:T,id:"fluid",style:{width:"100vw",height:"100vh",display:"block"}})})}])},11778,function(e){e.n(e.i(59941))}]);