(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,49067,e=>{"use strict";var t=e.i(43476),o=e.i(21663),u=e.i(56850),a=e.i(80075);let r={black:"#000000",white:"#ffffff",red:"#ff0000",green:"#00ff00",blue:"#0000ff",fuchsia:"#ff00ff",cyan:"#00ffff",yellow:"#ffff00",orange:"#ff8000"};function n(e){4===e.length&&(e=e[0]+e[1]+e[1]+e[2]+e[2]+e[3]+e[3]);let t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return t||console.warn(`Unable to convert hex string ${e} to rgb values`),[parseInt(t[1],16)/255,parseInt(t[2],16)/255,parseInt(t[3],16)/255]}function s(e){if(void 0===e)return[0,0,0];if(3==arguments.length)return arguments;if(!isNaN(e)){var t;return[((t=parseInt(t=e))>>16&255)/255,(t>>8&255)/255,(255&t)/255]}return"#"===e[0]?n(e):r[e.toLowerCase()]?n(r[e.toLowerCase()]):(console.warn("Color format not recognised"),[0,0,0])}class i extends Array{constructor(e){if(Array.isArray(e))return super(...e);return super(...s(...arguments))}get r(){return this[0]}get g(){return this[1]}get b(){return this[2]}set r(e){this[0]=e}set g(e){this[1]=e}set b(e){this[2]=e}set(e){return Array.isArray(e)?this.copy(e):this.copy(s(...arguments))}copy(e){return this[0]=e[0],this[1]=e[1],this[2]=e[2],this}}var l=e.i(53604),f=e.i(71645);let c=`
attribute vec2 uv;
attribute vec2 position;

varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = vec4(position, 0, 1);
}
`,v=`
precision highp float;

uniform float uTime;
uniform vec3 uResolution;
uniform vec2 uFocal;
uniform vec2 uRotation;
uniform float uStarSpeed;
uniform float uDensity;
uniform float uHueShift;
uniform float uSpeed;
uniform vec2 uMouse;
uniform float uGlowIntensity;
uniform float uSaturation;
uniform bool uMouseRepulsion;
uniform float uTwinkleIntensity;
uniform float uRotationSpeed;
uniform float uRepulsionStrength;
uniform float uMouseActiveFactor;
uniform float uAutoCenterRepulsion;
uniform bool uTransparent;

varying vec2 vUv;

#define NUM_LAYER 4.0
#define STAR_COLOR_CUTOFF 0.2
#define MAT45 mat2(0.7071, -0.7071, 0.7071, 0.7071)
#define PERIOD 3.0

float Hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

float tri(float x) {
  return abs(fract(x) * 2.0 - 1.0);
}

float tris(float x) {
  float t = fract(x);
  return 1.0 - smoothstep(0.0, 1.0, abs(2.0 * t - 1.0));
}

float trisn(float x) {
  float t = fract(x);
  return 2.0 * (1.0 - smoothstep(0.0, 1.0, abs(2.0 * t - 1.0))) - 1.0;
}

vec3 hsv2rgb(vec3 c) {
  vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
  vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
  return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

float Star(vec2 uv, float flare) {
  float d = length(uv);
  float m = (0.05 * uGlowIntensity) / d;
  float rays = smoothstep(0.0, 1.0, 1.0 - abs(uv.x * uv.y * 1000.0));
  m += rays * flare * uGlowIntensity;
  uv *= MAT45;
  rays = smoothstep(0.0, 1.0, 1.0 - abs(uv.x * uv.y * 1000.0));
  m += rays * 0.3 * flare * uGlowIntensity;
  m *= smoothstep(1.0, 0.2, d);
  return m;
}

vec3 StarLayer(vec2 uv) {
  vec3 col = vec3(0.0);

  vec2 gv = fract(uv) - 0.5; 
  vec2 id = floor(uv);

  for (int y = -1; y <= 1; y++) {
    for (int x = -1; x <= 1; x++) {
      vec2 offset = vec2(float(x), float(y));
      vec2 si = id + vec2(float(x), float(y));
      float seed = Hash21(si);
      float size = fract(seed * 345.32);
      float glossLocal = tri(uStarSpeed / (PERIOD * seed + 1.0));
      float flareSize = smoothstep(0.9, 1.0, size) * glossLocal;

      float red = smoothstep(STAR_COLOR_CUTOFF, 1.0, Hash21(si + 1.0)) + STAR_COLOR_CUTOFF;
      float blu = smoothstep(STAR_COLOR_CUTOFF, 1.0, Hash21(si + 3.0)) + STAR_COLOR_CUTOFF;
      float grn = min(red, blu) * seed;
      vec3 base = vec3(red, grn, blu);
      
      float hue = atan(base.g - base.r, base.b - base.r) / (2.0 * 3.14159) + 0.5;
      hue = fract(hue + uHueShift / 360.0);
      float sat = length(base - vec3(dot(base, vec3(0.299, 0.587, 0.114)))) * uSaturation;
      float val = max(max(base.r, base.g), base.b);
      base = hsv2rgb(vec3(hue, sat, val));

      vec2 pad = vec2(tris(seed * 34.0 + uTime * uSpeed / 10.0), tris(seed * 38.0 + uTime * uSpeed / 30.0)) - 0.5;

      float star = Star(gv - offset - pad, flareSize);
      vec3 color = base;

      float twinkle = trisn(uTime * uSpeed + seed * 6.2831) * 0.5 + 1.0;
      twinkle = mix(1.0, twinkle, uTwinkleIntensity);
      star *= twinkle;
      
      col += star * size * color;
    }
  }

  return col;
}

void main() {
  vec2 focalPx = uFocal * uResolution.xy;
  vec2 uv = (vUv * uResolution.xy - focalPx) / uResolution.y;

  vec2 mouseNorm = uMouse - vec2(0.5);
  
  if (uAutoCenterRepulsion > 0.0) {
    vec2 centerUV = vec2(0.0, 0.0);
    float centerDist = length(uv - centerUV);
    vec2 repulsion = normalize(uv - centerUV) * (uAutoCenterRepulsion / (centerDist + 0.1));
    uv += repulsion * 0.05;
  } else if (uMouseRepulsion) {
    vec2 mousePosUV = (uMouse * uResolution.xy - focalPx) / uResolution.y;
    float mouseDist = length(uv - mousePosUV);
    vec2 repulsion = normalize(uv - mousePosUV) * (uRepulsionStrength / (mouseDist + 0.1));
    uv += repulsion * 0.05 * uMouseActiveFactor;
  } else {
    vec2 mouseOffset = mouseNorm * 0.1 * uMouseActiveFactor;
    uv += mouseOffset;
  }

  float autoRotAngle = uTime * uRotationSpeed;
  mat2 autoRot = mat2(cos(autoRotAngle), -sin(autoRotAngle), sin(autoRotAngle), cos(autoRotAngle));
  uv = autoRot * uv;

  uv = mat2(uRotation.x, -uRotation.y, uRotation.y, uRotation.x) * uv;

  vec3 col = vec3(0.0);

  for (float i = 0.0; i < 1.0; i += 1.0 / NUM_LAYER) {
    float depth = fract(i + uStarSpeed * uSpeed);
    float scale = mix(20.0 * uDensity, 0.5 * uDensity, depth);
    float fade = depth * smoothstep(1.0, 0.9, depth);
    col += StarLayer(uv * scale + i * 453.32) * fade;
  }

  if (uTransparent) {
    float alpha = length(col);
    alpha = smoothstep(0.0, 0.3, alpha);
    alpha = min(alpha, 1.0);
    gl_FragColor = vec4(col, alpha);
  } else {
    gl_FragColor = vec4(col, 1.0);
  }
}
`;e.s(["default",0,function({focal:e=[.5,.5],rotation:r=[1,0],starSpeed:n=.5,density:s=1,hueShift:m=140,disableAnimation:p=!1,speed:h=1,mouseInteraction:d=!0,glowIntensity:y=.3,saturation:g=0,mouseRepulsion:R=!0,repulsionStrength:x=2,twinkleIntensity:S=.3,rotationSpeed:A=.1,autoCenterRepulsion:b=0,transparent:w=!0,...T}){let C=(0,f.useRef)(null),F=(0,f.useRef)({x:.5,y:.5}),L=(0,f.useRef)({x:.5,y:.5}),O=(0,f.useRef)(0),U=(0,f.useRef)(0);return(0,f.useEffect)(()=>{let t,f;if(!C.current)return;let T=C.current,_=new o.Renderer({alpha:w,premultipliedAlpha:!1}),M=_.gl;function E(){_.setSize(+T.offsetWidth,+T.offsetHeight),t&&(t.uniforms.uResolution.value=new i(M.canvas.width,M.canvas.height,M.canvas.width/M.canvas.height))}w?(M.enable(M.BLEND),M.blendFunc(M.SRC_ALPHA,M.ONE_MINUS_SRC_ALPHA),M.clearColor(0,0,0,0)):M.clearColor(0,0,0,1),window.addEventListener("resize",E,!1),E();let I=new l.Triangle(M);t=new u.Program(M,{vertex:c,fragment:v,uniforms:{uTime:{value:0},uResolution:{value:new i(M.canvas.width,M.canvas.height,M.canvas.width/M.canvas.height)},uFocal:{value:new Float32Array(e)},uRotation:{value:new Float32Array(r)},uStarSpeed:{value:n},uDensity:{value:s},uHueShift:{value:m},uSpeed:{value:h},uMouse:{value:new Float32Array([L.current.x,L.current.y])},uGlowIntensity:{value:y},uSaturation:{value:g},uMouseRepulsion:{value:R},uTwinkleIntensity:{value:S},uRotationSpeed:{value:A},uRepulsionStrength:{value:x},uMouseActiveFactor:{value:0},uAutoCenterRepulsion:{value:b},uTransparent:{value:w}}});let P=new a.Mesh(M,{geometry:I,program:t});function z(e){let t=T.getBoundingClientRect();F.current={x:(e.clientX-t.left)/t.width,y:1-(e.clientY-t.top)/t.height},O.current=1}function D(){O.current=0}return f=requestAnimationFrame(function e(o){f=requestAnimationFrame(e),p||(t.uniforms.uTime.value=.001*o,t.uniforms.uStarSpeed.value=.001*o*n/10),L.current.x+=(F.current.x-L.current.x)*.05,L.current.y+=(F.current.y-L.current.y)*.05,U.current+=(O.current-U.current)*.05,t.uniforms.uMouse.value[0]=L.current.x,t.uniforms.uMouse.value[1]=L.current.y,t.uniforms.uMouseActiveFactor.value=U.current,_.render({scene:P})}),T.appendChild(M.canvas),d&&(T.addEventListener("mousemove",z),T.addEventListener("mouseleave",D)),()=>{cancelAnimationFrame(f),window.removeEventListener("resize",E),d&&(T.removeEventListener("mousemove",z),T.removeEventListener("mouseleave",D)),T.contains(M.canvas)&&T.removeChild(M.canvas),M.getExtension("WEBGL_lose_context")?.loseContext()}},[e,r,n,s,m,p,h,d,y,g,R,S,A,x,b,w]),(0,t.jsx)("div",{ref:C,className:"galaxy-container",...T})}],49067)},85839,function(e){e.n(e.i(49067))}]);