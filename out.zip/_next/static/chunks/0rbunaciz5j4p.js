(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,7295,e=>{"use strict";var o=e.i(43476),l=e.i(71645),r=e.i(21663),t=e.i(56850),u=e.i(80075),n=e.i(53604);let a=e=>{let o=e.replace("#","").padEnd(6,"0");return[parseInt(o.slice(0,2),16)/255,parseInt(o.slice(2,4),16)/255,parseInt(o.slice(4,6),16)/255]},i=`
attribute vec2 position;
attribute vec2 uv;
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`,f=`
precision highp float;

uniform vec3  iResolution;
uniform vec2  iMouse;
uniform float iTime;

uniform vec3  uColor0;
uniform vec3  uColor1;
uniform vec3  uColor2;
uniform vec3  uColor3;
uniform vec3  uColor4;
uniform vec3  uColor5;
uniform vec3  uColor6;
uniform vec3  uColor7;
uniform int   uColorCount;

uniform vec3  uMouseColor;
uniform vec2  uFlow;
uniform float uSpeed;
uniform float uScale;
uniform float uTurbulence;
uniform float uFluidity;
uniform float uRimWidth;
uniform float uSharpness;
uniform float uShimmer;
uniform float uGlow;
uniform float uOpacity;
uniform float uMouseEnabled;
uniform float uMouseStrength;
uniform float uMouseRadius;

varying vec2 vUv;

#define PI 3.14159265

vec3 palette(float h) {
  int count = uColorCount;
  if (count < 1) count = 1;
  int idx = int(floor(clamp(h, 0.0, 0.999999) * float(count)));
  if (idx <= 0) return uColor0;
  if (idx == 1) return uColor1;
  if (idx == 2) return uColor2;
  if (idx == 3) return uColor3;
  if (idx == 4) return uColor4;
  if (idx == 5) return uColor5;
  if (idx == 6) return uColor6;
  return uColor7;
}

float hash(vec3 p3) {
  p3 = fract(p3 * 0.1031);
  p3 += dot(p3, p3.zyx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float smin(float a, float b, float k) {
  float r = exp2(-a / k) + exp2(-b / k);
  return -k * log2(r);
}

float sinlerp(float a, float b, float w) {
  return mix(a, b, (sin(w * PI - PI / 2.0) + 1.0) / 2.0);
}

float vn(vec2 p, float s, float seed) {
  vec2 cellp = floor(p / s);
  vec2 relp = mod(p, s);
  float g1 = hash(vec3(cellp, seed));
  float g2 = hash(vec3(cellp.x + 1.0, cellp.y, seed));
  float g3 = hash(vec3(cellp.x + 1.0, cellp.y + 1.0, seed));
  float g4 = hash(vec3(cellp.x, cellp.y + 1.0, seed));
  float bx = sinlerp(g1, g2, relp.x / s);
  float tx = sinlerp(g4, g3, relp.x / s);
  return sinlerp(bx, tx, relp.y / s);
}

float dbn(vec2 p, float s, float seed) {
  float o = s / 2.0;
  float n0 = vn(p, s, seed);
  float n1 = vn(p + vec2(o, o), s, seed + 0.1);
  float n2 = vn(p + vec2(-o, o), s, seed + 0.2);
  float n3 = vn(p + vec2(o, -o), s, seed + 0.3);
  float n4 = vn(p + vec2(-o, -o), s, seed + 0.4);
  return (2.0 * n0 + 1.5 * n1 + 1.25 * n2 + 1.125 * n3 + n4) / 7.0;
}

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
  float ref = 700.0 / max(uScale, 0.05);
  vec2 p = fragCoord / iResolution.y * ref;

  float spd = 200.0 * uSpeed;
  float t = iTime;

  vec2 dir = uFlow;
  vec2 perp = vec2(-dir.y, dir.x);

  float distort1 = vn(p + perp * (t * spd), 60.0, 10.0) * 50.0 * uTurbulence;
  float distort2 = vn(p - perp * (t * spd), 120.0, 15.0) * 100.0 * uTurbulence;

  float peaks = dbn(p + distort1 + dir * (t * spd * 0.5), 40.0, 1.0);
  float peaks2 = dbn(p + distort2 - dir * (t * spd * 0.5), 40.0, 0.0);

  float mapeaks = smin(peaks, peaks2, max(uFluidity, 0.001));

  float mGlow = 0.0;
  if (uMouseEnabled > 0.5) {
    vec2 mp = iMouse / iResolution.y * ref;
    float md = length(p - mp) / ref;
    float rr = max(uMouseRadius, 0.02);
    mGlow = exp(-md * md / (rr * rr)) * uMouseStrength;
  }

  float band = (uRimWidth - abs((mapeaks - 0.4) * 2.0)) * 5.0;
  float ltn = clamp(band - vn(p + dir * (t * spd * 0.5), 60.0, 12.0) * uShimmer, 0.0, 1.0);
  ltn = pow(ltn, uSharpness) * uGlow;
  ltn *= clamp(1.0 - mGlow, 0.0, 1.0);

  float h = clamp(0.5 + (peaks - peaks2) * 0.8, 0.0, 1.0);
  vec3 col = palette(h);

  vec3 outc = col * ltn;
  float a = clamp(max(outc.r, max(outc.g, outc.b)), 0.0, 1.0);
  fragColor = vec4(outc, a * uOpacity);
}

void main() {
  vec4 color;
  mainImage(color, vUv * iResolution.xy);
  gl_FragColor = color;
}
`;e.s(["default",0,({className:e,dpr:c,paused:s=!1,colors:v=["#ffffff","#ffffff","#ffffff"],speed:p=.5,scale:d=1.6,turbulence:m=1,fluidity:h=.1,rimWidth:g=.2,sharpness:C=2.5,shimmer:x=1.5,glow:b=2,flowDirection:w="down",opacity:y=1,mouseInteraction:R=!0,mouseStrength:M=1,mouseRadius:S=.35,mouseDampening:k=.15,mixBlendMode:F})=>{let T=(0,l.useRef)(null),E=(0,l.useRef)(null),B=(0,l.useRef)(null),I=(0,l.useRef)(null),P=(0,l.useRef)(null),G=(0,l.useRef)(null),O=(0,l.useRef)([0,0]),U=(0,l.useRef)(0);return(0,l.useEffect)(()=>{let e=T.current;if(!e)return;let o=new r.Renderer({dpr:c??(window.devicePixelRatio||1),alpha:!0,antialias:!0});G.current=o;let l=o.gl,F=l.canvas;l.clearColor(0,0,0,0),F.style.width="100%",F.style.height="100%",F.style.display="block",e.appendChild(F);let{arr:A,count:W,avg:z}=(e=>{let o=(e&&e.length?e:["#4F46E5","#06B6D4","#E0F2FE"]).slice(0,8),l=o.length,r=[];for(let e=0;e<8;e++)r.push(a(o[Math.min(e,o.length-1)]));let t=[0,0,0];for(let e=0;e<l;e++)t[0]+=r[e][0],t[1]+=r[e][1],t[2]+=r[e][2];return t[0]/=l,t[1]/=l,t[2]/=l,{arr:r,count:l,avg:t}})(v),j={iResolution:{value:[l.drawingBufferWidth,l.drawingBufferHeight,1]},iMouse:{value:[0,0]},iTime:{value:0},uColor0:{value:A[0]},uColor1:{value:A[1]},uColor2:{value:A[2]},uColor3:{value:A[3]},uColor4:{value:A[4]},uColor5:{value:A[5]},uColor6:{value:A[6]},uColor7:{value:A[7]},uColorCount:{value:W},uMouseColor:{value:z},uFlow:{value:(e=>{switch(e){case"up":return[0,1];case"down":default:return[0,-1];case"left":return[-1,0];case"right":return[1,0]}})(w)},uSpeed:{value:p},uScale:{value:d},uTurbulence:{value:m},uFluidity:{value:h},uRimWidth:{value:g},uSharpness:{value:C},uShimmer:{value:x},uGlow:{value:b},uOpacity:{value:y},uMouseEnabled:{value:+!!R},uMouseStrength:{value:M},uMouseRadius:{value:S}},q=new t.Program(l,{vertex:i,fragment:f,uniforms:j});B.current=q;let H=new n.Triangle(l);P.current=H,I.current=new u.Mesh(l,{geometry:H,program:q});let K=()=>{let r=e.getBoundingClientRect();o.setSize(r.width,r.height),j.iResolution.value=[l.drawingBufferWidth,l.drawingBufferHeight,1]};K();let L=new ResizeObserver(K);L.observe(e);let _=e=>{let l=F.getBoundingClientRect(),r=o.dpr||1,t=(e.clientX-l.left)*r,u=(l.height-(e.clientY-l.top))*r;O.current=[t,u],k<=0&&(j.iMouse.value=[t,u])};R&&F.addEventListener("pointermove",_);let D=e=>{if(E.current=requestAnimationFrame(D),j.iTime.value=.001*e,k>0){U.current||(U.current=e);let o=(e-U.current)/1e3;U.current=e;let l=1-Math.exp(-o/Math.max(1e-4,k));l>1&&(l=1);let r=O.current,t=j.iMouse.value;t[0]+=(r[0]-t[0])*l,t[1]+=(r[1]-t[1])*l}else U.current=e;if(!s&&B.current&&I.current)try{o.render({scene:I.current})}catch(e){console.error(e)}};return E.current=requestAnimationFrame(D),()=>{E.current&&cancelAnimationFrame(E.current),R&&F.removeEventListener("pointermove",_),L.disconnect(),F.parentElement===e&&e.removeChild(F);let o=(e,o)=>{let l=e&&e[o];"function"==typeof l&&l.call(e)};o(B.current,"remove"),o(P.current,"remove"),o(I.current,"remove"),o(G.current,"destroy"),B.current=null,P.current=null,I.current=null,G.current=null}},[c,s,v,p,d,m,h,g,C,x,b,w,y,R,M,S,k]),(0,o.jsx)("div",{ref:T,className:`ferrofluid-container ${e??""}`,style:{...F&&{mixBlendMode:F}}})}])},69015,function(e){e.n(e.i(7295))}]);