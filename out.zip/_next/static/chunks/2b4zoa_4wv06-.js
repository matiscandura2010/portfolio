(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,89990,t=>{"use strict";var e=t.i(43476),i=t.i(71645),a=t.i(21663),r=t.i(56850),s=t.i(80075),n=t.i(53604);let l=new Uint8Array(4),h=1;class o{constructor(t,{image:e,target:i=t.TEXTURE_2D,type:a=t.UNSIGNED_BYTE,format:r=t.RGBA,internalFormat:s=r,wrapS:n=t.CLAMP_TO_EDGE,wrapT:l=t.CLAMP_TO_EDGE,wrapR:o=t.CLAMP_TO_EDGE,generateMipmaps:u=i===(t.TEXTURE_2D||t.TEXTURE_CUBE_MAP),minFilter:g=u?t.NEAREST_MIPMAP_LINEAR:t.LINEAR,magFilter:p=t.LINEAR,premultiplyAlpha:m=!1,unpackAlignment:c=4,flipY:f=i==(t.TEXTURE_2D||t.TEXTURE_3D),anisotropy:d=0,level:v=0,width:T,height:E=T,length:x=1}={}){this.gl=t,this.id=h++,this.image=e,this.target=i,this.type=a,this.format=r,this.internalFormat=s,this.minFilter=g,this.magFilter=p,this.wrapS=n,this.wrapT=l,this.wrapR=o,this.generateMipmaps=u,this.premultiplyAlpha=m,this.unpackAlignment=c,this.flipY=f,this.anisotropy=Math.min(d,this.gl.renderer.parameters.maxAnisotropy),this.level=v,this.width=T,this.height=E,this.length=x,this.texture=this.gl.createTexture(),this.store={image:null},this.glState=this.gl.renderer.state,this.state={},this.state.minFilter=this.gl.NEAREST_MIPMAP_LINEAR,this.state.magFilter=this.gl.LINEAR,this.state.wrapS=this.gl.REPEAT,this.state.wrapT=this.gl.REPEAT,this.state.anisotropy=0}bind(){this.glState.textureUnits[this.glState.activeTextureUnit]!==this.id&&(this.gl.bindTexture(this.target,this.texture),this.glState.textureUnits[this.glState.activeTextureUnit]=this.id)}update(t=0){let e=!(this.image===this.store.image&&!this.needsUpdate);if((e||this.glState.textureUnits[t]!==this.id)&&(this.gl.renderer.activeTexture(t),this.bind()),e){if(this.needsUpdate=!1,this.flipY!==this.glState.flipY&&(this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL,this.flipY),this.glState.flipY=this.flipY),this.premultiplyAlpha!==this.glState.premultiplyAlpha&&(this.gl.pixelStorei(this.gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,this.premultiplyAlpha),this.glState.premultiplyAlpha=this.premultiplyAlpha),this.unpackAlignment!==this.glState.unpackAlignment&&(this.gl.pixelStorei(this.gl.UNPACK_ALIGNMENT,this.unpackAlignment),this.glState.unpackAlignment=this.unpackAlignment),this.minFilter!==this.state.minFilter&&(this.gl.texParameteri(this.target,this.gl.TEXTURE_MIN_FILTER,this.minFilter),this.state.minFilter=this.minFilter),this.magFilter!==this.state.magFilter&&(this.gl.texParameteri(this.target,this.gl.TEXTURE_MAG_FILTER,this.magFilter),this.state.magFilter=this.magFilter),this.wrapS!==this.state.wrapS&&(this.gl.texParameteri(this.target,this.gl.TEXTURE_WRAP_S,this.wrapS),this.state.wrapS=this.wrapS),this.wrapT!==this.state.wrapT&&(this.gl.texParameteri(this.target,this.gl.TEXTURE_WRAP_T,this.wrapT),this.state.wrapT=this.wrapT),this.wrapR!==this.state.wrapR&&(this.gl.texParameteri(this.target,this.gl.TEXTURE_WRAP_R,this.wrapR),this.state.wrapR=this.wrapR),this.anisotropy&&this.anisotropy!==this.state.anisotropy&&(this.gl.texParameterf(this.target,this.gl.renderer.getExtension("EXT_texture_filter_anisotropic").TEXTURE_MAX_ANISOTROPY_EXT,this.anisotropy),this.state.anisotropy=this.anisotropy),this.image){if(this.image.width&&(this.width=this.image.width,this.height=this.image.height),this.target===this.gl.TEXTURE_CUBE_MAP)for(let t=0;t<6;t++)this.gl.texImage2D(this.gl.TEXTURE_CUBE_MAP_POSITIVE_X+t,this.level,this.internalFormat,this.format,this.type,this.image[t]);else if(ArrayBuffer.isView(this.image))this.target===this.gl.TEXTURE_2D?this.gl.texImage2D(this.target,this.level,this.internalFormat,this.width,this.height,0,this.format,this.type,this.image):(this.target===this.gl.TEXTURE_2D_ARRAY||this.target===this.gl.TEXTURE_3D)&&this.gl.texImage3D(this.target,this.level,this.internalFormat,this.width,this.height,this.length,0,this.format,this.type,this.image);else if(this.image.isCompressedTexture)for(let t=0;t<this.image.length;t++)this.gl.compressedTexImage2D(this.target,t,this.internalFormat,this.image[t].width,this.image[t].height,0,this.image[t].data);else this.target===this.gl.TEXTURE_2D?this.gl.texImage2D(this.target,this.level,this.internalFormat,this.format,this.type,this.image):this.gl.texImage3D(this.target,this.level,this.internalFormat,this.width,this.height,this.length,0,this.format,this.type,this.image);if(this.generateMipmaps){var i,a;this.gl.renderer.isWebgl2||((i=this.image.width)&i-1)==0&&((a=this.image.height)&a-1)==0?this.gl.generateMipmap(this.target):(this.generateMipmaps=!1,this.wrapS=this.wrapT=this.gl.CLAMP_TO_EDGE,this.minFilter=this.gl.LINEAR)}this.onUpdate&&this.onUpdate()}else if(this.target===this.gl.TEXTURE_CUBE_MAP)for(let t=0;t<6;t++)this.gl.texImage2D(this.gl.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,this.gl.RGBA,1,1,0,this.gl.RGBA,this.gl.UNSIGNED_BYTE,l);else this.width?this.target===this.gl.TEXTURE_2D?this.gl.texImage2D(this.target,this.level,this.internalFormat,this.width,this.height,0,this.format,this.type,null):this.gl.texImage3D(this.target,this.level,this.internalFormat,this.width,this.height,this.length,0,this.format,this.type,null):this.gl.texImage2D(this.target,0,this.gl.RGBA,1,1,0,this.gl.RGBA,this.gl.UNSIGNED_BYTE,l);this.store.image=this.image}}}let u=`#version 300 es
in vec2 position;
in vec2 uv;
out vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`,g=`#version 300 es
precision highp float;

uniform sampler2D uTextTexture;
uniform vec2 uResolution;
uniform vec2 uPointer;
uniform float uPointerActive;
uniform float uTime;
uniform float uWarpStrength;
uniform float uWarpScale;
uniform float uSpeed;
uniform float uPointerInfluence;
uniform float uPointerStrength;
uniform float uRefraction;
uniform float uRipple;
uniform float uMotion;

in vec2 vUv;
out vec4 fragColor;

float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);

  float a = hash(i);
  float b = hash(i + vec2(1.0, 0.0));
  float c = hash(i + vec2(0.0, 1.0));
  float d = hash(i + vec2(1.0, 1.0));

  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  for (int i = 0; i < 4; i++) {
    value += amplitude * noise(p);
    p *= 2.02;
    amplitude *= 0.5;
  }
  return value;
}

vec4 sampleText(vec2 uv) {
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
    return vec4(0.0);
  }
  return texture(uTextTexture, uv);
}

void main() {
  vec2 uv = vUv;
  float aspect = uResolution.x / max(uResolution.y, 1.0);
  float time = uTime * uSpeed;
  float scale = max(uWarpScale, 0.001);

  vec2 drift = vec2(time * 0.055, -time * 0.045);
  float n1 = fbm(uv * scale * 3.1 + drift);
  float n2 = fbm((uv + 19.17) * scale * 3.4 - drift.yx);
  vec2 ambient = (vec2(n1, n2) - 0.5) * uWarpStrength * 0.045 * uMotion;

  vec2 pointerDelta = uv - uPointer;
  vec2 aspectDelta = vec2(pointerDelta.x * aspect, pointerDelta.y);
  float dist = length(aspectDelta);
  float radius = max(uPointerInfluence, 0.001);
  float t = clamp(dist / radius, 0.0, 1.0);
  float lens = smoothstep(radius, 0.0, dist) * uPointerActive;
  float bulge = t * (1.0 - t) * (1.0 - t) * 6.75 * uPointerActive;
  vec2 dir = dist > 0.0001 ? vec2(aspectDelta.x / aspect, aspectDelta.y) / dist : vec2(0.0);

  float rippleWave = sin(dist * 28.0 - time * 4.2) * 0.5 + 0.5;
  float rippleRing = (rippleWave - 0.5) * uRipple;
  vec2 pointerWarp = -dir * bulge * uPointerStrength * 0.045;
  pointerWarp += dir * rippleRing * bulge * uPointerStrength * 0.016;

  vec2 displaced = uv + ambient + pointerWarp;
  vec2 splitDir = ambient + pointerWarp;
  float splitLen = length(splitDir);
  splitDir = splitLen > 0.00001 ? splitDir / splitLen : vec2(0.7071, 0.7071);
  vec2 split = splitDir * uRefraction * 0.16 * (0.35 + lens * 1.65);

  vec4 base = sampleText(displaced);
  float r = sampleText(displaced + split).r;
  float g = base.g;
  float b = sampleText(displaced - split).b;
  float a = max(max(sampleText(displaced + split).a, base.a), sampleText(displaced - split).a);

  vec3 color = vec3(r, g, b) + lens * base.a * 0.055;
  fragColor = vec4(color, a);
}
`,p=t=>"number"==typeof t?`${t}px`:t,m=(t,e,i)=>{let a=Array.from(e);return a.reduce((e,i)=>e+t.measureText(i).width,0)+Math.max(0,a.length-1)*i},c=(t,e)=>{let i=t.uniforms;i.uWarpStrength.value=e.warpStrength,i.uWarpScale.value=e.warpScale,i.uSpeed.value=e.speed,i.uPointerInfluence.value=e.pointerInfluence,i.uPointerStrength.value=e.pointerStrength,i.uRefraction.value=e.refraction,i.uRipple.value=+!!e.ripple};t.s(["default",0,({text:t="Bend the moment",color:l="#f8f5ff",warpStrength:h=.08,warpScale:f=1.7,speed:d=.55,pointerInfluence:v=.42,pointerStrength:T=.38,refraction:E=.018,ripple:x=!0,fontSize:w="clamp(3rem, 10vw, 9rem)",fontWeight:R=800,fontFamily:A="inherit",letterSpacing:S="-0.06em",lineHeight:_=.9,className:y="",style:P})=>{let U=(0,i.useRef)(null),b=(0,i.useRef)({text:t,color:l,fontSize:w,fontWeight:R,fontFamily:A,letterSpacing:S,lineHeight:_,warpStrength:h,warpScale:f,speed:d,pointerInfluence:v,pointerStrength:T,refraction:E,ripple:x}),F=(0,i.useRef)(null);return(0,i.useEffect)(()=>{b.current={text:t,color:l,fontSize:w,fontWeight:R,fontFamily:A,letterSpacing:S,lineHeight:_,warpStrength:h,warpScale:f,speed:d,pointerInfluence:v,pointerStrength:T,refraction:E,ripple:x},F.current&&(c(F.current.program,b.current),F.current.rasterize())},[t,l,w,R,A,S,_,h,f,d,v,T,E,x]),(0,i.useEffect)(()=>{let t,e,i,l,h,f,d,v,T=U.current;if(!T)return;let E=0,x=!1,w=!1,R=!0,A=!document.hidden,S=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,_=0,y={x:.5,y:.5,tx:.5,ty:.5,active:0,activeTarget:0},P=performance.now();try{e=(t=new a.Renderer({webgl:2,alpha:!0,premultipliedAlpha:!1,antialias:!0,dpr:Math.min(window.devicePixelRatio||1,2)})).gl}catch(t){console.warn("WarpText: WebGL could not be initialized.",t);return}e.clearColor(0,0,0,0);let M=e.canvas;M.style.cssText="position:absolute;inset:0;width:100%;height:100%;display:block;",M.setAttribute("aria-hidden","true"),T.appendChild(M),f=new o(e,{generateMipmaps:!1,minFilter:e.LINEAR,magFilter:e.LINEAR,wrapS:e.CLAMP_TO_EDGE,wrapT:e.CLAMP_TO_EDGE}),l=new n.Triangle(e),i=new r.Program(e,{vertex:u,fragment:g,transparent:!0,depthTest:!1,depthWrite:!1,uniforms:{uTextTexture:{value:f},uResolution:{value:new Float32Array([1,1])},uPointer:{value:new Float32Array([.5,.5])},uPointerActive:{value:0},uTime:{value:0},uWarpStrength:{value:b.current.warpStrength},uWarpScale:{value:b.current.warpScale},uSpeed:{value:b.current.speed},uPointerInfluence:{value:b.current.pointerInfluence},uPointerStrength:{value:b.current.pointerStrength},uRefraction:{value:b.current.refraction},uRipple:{value:+!!b.current.ripple},uMotion:{value:+!S}}}),h=new s.Mesh(e,{geometry:l,program:i});let D=()=>{x||w||t.render({scene:h})},I=async()=>{let t=++_;if(document.fonts?.ready)try{await document.fonts.ready}catch{}if(x||w||t!==_)return;let e=T.getBoundingClientRect();if(e.width<=0||e.height<=0)return;let i=Math.min(window.devicePixelRatio||1,2);f.image=(({container:t,width:e,height:i,dpr:a,props:r})=>{let s=document.createElement("canvas");s.width=Math.max(1,Math.floor(e*a)),s.height=Math.max(1,Math.floor(i*a));let n=s.getContext("2d");if(!n)return s;let l=document.createElement("span");l.textContent=r.text,Object.assign(l.style,{position:"absolute",visibility:"hidden",pointerEvents:"none",whiteSpace:"pre",inset:"0 auto auto 0",fontFamily:r.fontFamily,fontSize:p(r.fontSize),fontWeight:String(r.fontWeight),letterSpacing:p(r.letterSpacing),lineHeight:"number"==typeof r.lineHeight?String(r.lineHeight):r.lineHeight}),t.appendChild(l);let h=window.getComputedStyle(l),o=parseFloat(h.fontSize)||96,u=h.fontFamily||"sans-serif",g=h.fontWeight||String(r.fontWeight),c="normal"===h.letterSpacing?0:parseFloat(h.letterSpacing)||0,f=parseFloat(h.lineHeight);Number.isFinite(f)||(f=o*("number"==typeof r.lineHeight?r.lineHeight:.92)),l.remove(),n.setTransform(a,0,0,a,0,0),n.clearRect(0,0,e,i),n.textAlign="left",n.textBaseline="middle",n.fillStyle=r.color,n.imageSmoothingEnabled=!0,n.imageSmoothingQuality="high";let d=String(r.text||"").split("\n"),v=()=>{n.font=`${g} ${o}px ${u}`};v();let T=.78*i,E=Math.min(1,.86*e/Math.max(...d.map(t=>m(n,t,c)),1),T/Math.max(f*d.length,1));E<1&&(o*=E,c*=E,f*=E,v());let x=i/2-f*(d.length-1)/2;return d.forEach((t,i)=>{var a,r,s;let l,h;return a=e/2,r=x+i*f,s=c,l=Array.from(t),h=a-m(n,t,s)/2,void l.forEach((t,e)=>{n.fillText(t,h,r),h+=n.measureText(t).width+(e===l.length-1?0:s)})}),s})({container:T,width:e.width,height:e.height,dpr:i,props:b.current}),f.needsUpdate=!0,D()},L=()=>{if(x||w)return;let a=T.getBoundingClientRect();a.width<=0||a.height<=0||(t.dpr=Math.min(window.devicePixelRatio||1,2),t.setSize(a.width,a.height),i.uniforms.uResolution.value[0]=e.drawingBufferWidth,i.uniforms.uResolution.value[1]=e.drawingBufferHeight,I())},C=t=>{if("touch"===t.pointerType)return;let e=M.getBoundingClientRect();e.width<=0||e.height<=0||(y.tx=(t.clientX-e.left)/e.width,y.ty=1-(t.clientY-e.top)/e.height,y.activeTarget=1)},W=()=>{y.activeTarget=0},B=t=>{t.preventDefault(),w=!0,E&&cancelAnimationFrame(E),E=0},N=()=>{(A=!document.hidden)&&R&&!E&&(E=requestAnimationFrame(O)),!A&&E&&(cancelAnimationFrame(E),E=0)},X=window.matchMedia?.("(prefers-reduced-motion: reduce)"),G=t=>{S=t.matches,i.uniforms.uMotion.value=+!S,D()},O=t=>{if(x||w)return;let e=(t-P)*.001,a=.5+.12*Math.sin(.33*e),r=.5+.1*Math.cos(.27*e),s=y.activeTarget>0?y.tx:a,n=y.activeTarget>0?y.ty:r,l=y.activeTarget>0?.12:.035;y.x+=(s-y.x)*l,y.y+=(n-y.y)*l,y.active+=((y.activeTarget>0?1:.18)-y.active)*.06,i.uniforms.uPointer.value[0]=y.x,i.uniforms.uPointer.value[1]=y.y,i.uniforms.uPointerActive.value=S?.35*y.active:y.active,i.uniforms.uTime.value=S?0:e,D(),E=requestAnimationFrame(O)};return(d=new ResizeObserver(L)).observe(T),(v=new IntersectionObserver(([t])=>{(R=t.isIntersecting)&&A&&!E&&(E=requestAnimationFrame(O)),!R&&E&&(cancelAnimationFrame(E),E=0)},{threshold:0})).observe(T),M.addEventListener("pointermove",C),M.addEventListener("pointerleave",W),M.addEventListener("webglcontextlost",B,!1),document.addEventListener("visibilitychange",N),X?.addEventListener("change",G),c(i,b.current),F.current={program:i,rasterize:I},L(),E=requestAnimationFrame(O),()=>{if(x=!0,F.current=null,E&&cancelAnimationFrame(E),d?.disconnect(),v?.disconnect(),M.removeEventListener("pointermove",C),M.removeEventListener("pointerleave",W),M.removeEventListener("webglcontextlost",B),document.removeEventListener("visibilitychange",N),X?.removeEventListener("change",G),!w)try{f?.texture&&e.deleteTexture(f.texture),l?.remove?.(),i?.remove?.(),e.getExtension("WEBGL_lose_context")?.loseContext()}catch{}M.parentNode===T&&T.removeChild(M)}},[]),(0,e.jsx)("div",{ref:U,className:`warp-text ${y}`.trim(),style:P,role:"img","aria-label":t})}],89990)},32880,function(t){t.n(t.i(89990))}]);